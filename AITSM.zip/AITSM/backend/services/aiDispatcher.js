const { Configuration, OpenAIApi } = require('openai');

class AIDispatcher {
  constructor(teamResponsibilities) {
    const configuration = new Configuration({
      apiKey: process.env.OPENAI_API_KEY,
    });
    this.openai = new OpenAIApi(configuration);
    this.teamResponsibilities = teamResponsibilities;
  }

  async predictTeam(description) {
    const prompt = this.createPrompt(description);
    
    try {
      const response = await this.openai.createChatCompletion({
        model: "gpt-3.5-turbo",
        messages: [
          { role: "system", content: "You are a helpful assistant that predicts which team should handle a given request based on team responsibilities." },
          { role: "user", content: prompt }
        ],
        max_tokens: 50,
        n: 1,
        stop: null,
        temperature: 0.5,
      });

      if (response.data && response.data.choices && response.data.choices.length > 0) {
        const predictedTeam = response.data.choices[0].message.content.trim();
        console.log('Raw AI response:', predictedTeam);
        return predictedTeam;
      } else {
        throw new Error('Unexpected response from OpenAI API');
      }
    } catch (error) {
      console.error('Error calling OpenAI API:', error.response ? error.response.data : error.message);
      throw new Error('Failed to predict team');
    }
  }

  createPrompt(description) {
    let prompt = `Given the following team responsibilities:\n\n`;
    
    this.teamResponsibilities.forEach(team => {
      prompt += `${team.name}: ${team.responsibilities.join(', ')}\n`;
    });

    prompt += `\nBased on the following request description, which team should handle it? Please respond with only the team name.\n\nRequest: ${description}\n\nTeam:`;

    return prompt;
  }
}

module.exports = AIDispatcher;