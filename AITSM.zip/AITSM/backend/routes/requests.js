const express = require('express');
const { Request: ITRequest } = require('../models/Request');
const AIDispatcher = require('../services/aiDispatcher');
const teamResponsibilities = require('../config/teamResponsibilities');

const router = express.Router();
const aiDispatcher = new AIDispatcher(teamResponsibilities);

// Helper function to check if a team name is valid
const isValidTeam = (teamName) => {
  return teamResponsibilities.some(team => team.name.toLowerCase() === teamName.toLowerCase());
};

// Submit a new request
router.post('/', async (req, res) => {
  try {
    const { text } = req.body;
    const userId = req.userId;

    // Predict team using AI
    let predictedTeam;
    try {
      predictedTeam = await aiDispatcher.predictTeam(text);
      console.log('Predicted team:', predictedTeam); // Log the predicted team

      // Check if the predicted team is valid
      if (!isValidTeam(predictedTeam)) {
        console.log('Invalid team predicted, assigning to default team');
        predictedTeam = 'Unassigned'; // or any default team you prefer
      }
    } catch (aiError) {
      console.error('Error predicting team:', aiError);
      predictedTeam = 'Unassigned';
    }

    const newRequest = new ITRequest({
      text,
      user: userId,
      assignedTeam: predictedTeam,
      status: 'Open'
    });

    await newRequest.save();
    res.status(201).json(newRequest);
  } catch (error) {
    console.error('Error submitting request:', error);
    res.status(500).json({ message: 'Server error', error: error.message });
  }
});

// Get user requests
router.get('/', async (req, res) => {
  try {
    const requests = await ITRequest.find({ user: req.userId })
      .populate('user', 'email')
      .populate('comments.user', 'email')
      .select('text status assignedTeam createdAt comments'); // Make sure assignedTeam is included
    res.json(requests);
  } catch (error) {
    console.error('Error fetching user requests:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

// Add a comment to a request
router.post('/:requestId/comments', async (req, res) => {
  try {
    const { requestId } = req.params;
    const { text } = req.body;
    const userId = req.userId;

    const request = await ITRequest.findById(requestId);
    if (!request) {
      return res.status(404).json({ message: 'Request not found' });
    }

    request.comments.push({
      text,
      user: userId,
    });

    await request.save();
    await request.populate('comments.user', 'email');
    res.status(201).json(request);
  } catch (error) {
    console.error('Error adding comment:', error);
    res.status(500).json({ message: 'Server error', error: error.message });
  }
});

// Other routes (GET, PUT, etc.) remain unchanged

module.exports = router;