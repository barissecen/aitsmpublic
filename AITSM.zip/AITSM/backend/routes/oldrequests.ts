import express from 'express';
import { Request as ITRequest } from '../models/Request';
import { AIDispatcher } from '../services/aiDispatcher';
import { teamResponsibilities } from '../config/teamResponsibilities';

const router = express.Router();
const aiDispatcher = new AIDispatcher(teamResponsibilities);

// Submit a new request
router.post('/', async (req, res) => {
  try {
    const { text } = req.body;
    const userId = req.userId; // Assuming you have middleware to extract user ID from token

    // Predict team using AI
    const predictedTeam = await aiDispatcher.predictTeam(text);

    const newRequest = new ITRequest({
      text,
      user: userId,
      assignedTeam: predictedTeam,
      status: 'Open'
    });

    await newRequest.save();
    res.status(201).json(newRequest);
  } catch (error) {
    console.error('Error submitting request:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

// Other routes (GET, PUT, etc.) remain unchanged

export default router;