require('dotenv').config();
const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');
const User = require('../models/User');

mongoose.connect(process.env.MONGODB_URI, {
  useNewUrlParser: true,
  useUnifiedTopology: true,
})
.then(async () => {
  console.log('MongoDB connected');
  
  const hashedPassword = await bcrypt.hash('testpassword', 10);
  
  const testUser = new User({
    email: 'test@example.com',
    password: hashedPassword,
  });

  await testUser.save();
  console.log('Test user added successfully');
  mongoose.connection.close();
})
.catch(err => console.log('MongoDB connection error:', err));