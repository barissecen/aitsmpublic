module.exports = [
  {
    name: 'IT Support',
    responsibilities: ['hardware issues', 'software installation', 'network connectivity']
  },touch .gitignore
  {
    name: 'Development',
    responsibilities: ['bug fixes', 'feature development', 'code review']
  },
  {
    name: 'Security',
    responsibilities: ['access control', 'vulnerability assessment', 'security incident response']
  },
  // Add more teams as needed
];