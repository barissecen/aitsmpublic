const mongoose = require('mongoose');

const requestSchema = new mongoose.Schema({
  text: { type: String, required: true },
  user: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  assignedTeam: { type: String, required: true },
  status: { type: String, default: 'Open' },
  comments: [{
    text: String,
    user: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
    createdAt: { type: Date, default: Date.now }
  }],
  createdAt: { type: Date, default: Date.now }
});

const Request = mongoose.model('Request', requestSchema);

module.exports = { Request };