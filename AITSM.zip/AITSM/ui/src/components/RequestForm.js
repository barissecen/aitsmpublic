import React, { useState } from 'react';
import { submitRequest } from '../api/api';

const RequestForm = () => {
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState(null);
  const [success, setSuccess] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setSubmitting(true);
    setError(null);
    setSuccess(false);

    try {
      await submitRequest({ title, description });
      setSuccess(true);
      setTitle('');
      setDescription('');
    } catch (err) {
      setError(err.message || 'An error occurred while submitting the request.');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <form onSubmit={handleSubmit}>
      <input
        type="text"
        value={title}
        onChange={(e) => setTitle(e.target.value)}
        placeholder="Request Title"
        required
      />
      <textarea
        value={description}
        onChange={(e) => setDescription(e.target.value)}
        placeholder="Request Description"
        required
      />
      <button type="submit" disabled={submitting}>
        {submitting ? 'Submitting...' : 'Submit Request'}
      </button>
      {error && <p className="error">{error}</p>}
      {success && <p className="success">Request submitted successfully!</p>}
    </form>
  );
};

export default RequestForm;