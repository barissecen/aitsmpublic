import React, { useState, useEffect, useContext } from 'react';
import { submitRequest, getUserRequests, addCommentToRequest } from '../api/api';
import { useNavigate } from 'react-router-dom';
import { ThemeContext } from '../contexts/ThemeContext';

const Home = ({ setIsAuthenticated }) => {
  const [newRequest, setNewRequest] = useState('');
  const [userRequests, setUserRequests] = useState([]);
  const [newComments, setNewComments] = useState({});
  const [activeTab, setActiveTab] = useState("new-request");
  const [successMessage, setSuccessMessage] = useState('');
  const navigate = useNavigate();
  const { isDarkMode, toggleDarkMode } = useContext(ThemeContext);

  useEffect(() => {
    fetchUserRequests();
  }, []);

  const fetchUserRequests = async () => {
    try {
      const requests = await getUserRequests();
      setUserRequests(requests);
    } catch (error) {
      console.error('Error fetching user requests:', error);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (newRequest.trim()) {
      try {
        await submitRequest({ text: newRequest });
        setNewRequest('');
        fetchUserRequests();
        setSuccessMessage('Request submitted successfully!');
        setTimeout(() => setSuccessMessage(''), 3000); // Clear message after 3 seconds
      } catch (error) {
        console.error('Error submitting request:', error);
      }
    }
  };

  const handleAddComment = async (requestId) => {
    const commentText = newComments[requestId];
    if (commentText && commentText.trim()) {
      try {
        await addCommentToRequest(requestId, { text: commentText });
        setNewComments({ ...newComments, [requestId]: '' });
        fetchUserRequests();
      } catch (error) {
        console.error('Error adding comment:', error);
      }
    }
  };

  const handleLogout = () => {
    localStorage.removeItem('token');
    setIsAuthenticated(false);
    navigate('/login');
  };

  const formatDate = (dateString) => {
    const options = { year: 'numeric', month: 'long', day: 'numeric', hour: '2-digit', minute: '2-digit' };
    return new Date(dateString).toLocaleDateString(undefined, options);
  };

  return (
    <div className={`flex flex-col min-h-screen ${isDarkMode ? 'bg-gray-900 text-white' : 'bg-gray-100 text-black'}`}>
      <header className={`${isDarkMode ? 'bg-gray-800' : 'bg-white'} shadow-sm`}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <h1 className={`text-2xl font-bold ${isDarkMode ? 'text-white' : 'text-gray-900'}`}>IT Service Management</h1>
          </div>
          <div className="flex items-center space-x-4">
            <button 
              onClick={toggleDarkMode} 
              className={`p-2 rounded-full ${isDarkMode ? 'bg-gray-700 text-yellow-300' : 'bg-gray-200 text-gray-700'}`}
              aria-label={isDarkMode ? "Switch to light mode" : "Switch to dark mode"}
            >
              {isDarkMode ? (
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                  <path fillRule="evenodd" d="M10 2a1 1 0 011 1v1a1 1 0 11-2 0V3a1 1 0 011-1zm4 8a4 4 0 11-8 0 4 4 0 018 0zm-.464 4.95l.707.707a1 1 0 001.414-1.414l-.707-.707a1 1 0 00-1.414 1.414zm2.12-10.607a1 1 0 010 1.414l-.706.707a1 1 0 11-1.414-1.414l.707-.707a1 1 0 011.414 0zM17 11a1 1 0 100-2h-1a1 1 0 100 2h1zm-7 4a1 1 0 011 1v1a1 1 0 11-2 0v-1a1 1 0 011-1zM5.05 6.464A1 1 0 106.465 5.05l-.708-.707a1 1 0 00-1.414 1.414l.707.707zm1.414 8.486l-.707.707a1 1 0 01-1.414-1.414l.707-.707a1 1 0 011.414 1.414zM4 11a1 1 0 100-2H3a1 1 0 000 2h1z" clipRule="evenodd" />
                </svg>
              ) : (
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                  <path d="M17.293 13.293A8 8 0 016.707 2.707a8.001 8.001 0 1010.586 10.586z" />
                </svg>
              )}
            </button>
            <button onClick={handleLogout} className={`${isDarkMode ? 'text-gray-300 hover:text-white' : 'text-gray-500 hover:text-gray-900'}`}>
              Logout
            </button>
          </div>
        </div>
      </header>

      <main className="flex-grow max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="space-y-4">
          <div className="flex space-x-4">
            <button
              onClick={() => setActiveTab("new-request")}
              className={`px-4 py-2 rounded-md ${activeTab === "new-request" 
                ? (isDarkMode ? "bg-blue-600 text-white" : "bg-blue-500 text-white")
                : (isDarkMode ? "bg-gray-700 text-white" : "bg-white text-gray-700")}`}
            >
              New Request
            </button>
            <button
              onClick={() => setActiveTab("my-requests")}
              className={`px-4 py-2 rounded-md ${activeTab === "my-requests" 
                ? (isDarkMode ? "bg-blue-600 text-white" : "bg-blue-500 text-white")
                : (isDarkMode ? "bg-gray-700 text-white" : "bg-white text-gray-700")}`}
            >
              My Requests
            </button>
          </div>

          {activeTab === "new-request" && (
            <div className={`${isDarkMode ? 'bg-gray-800' : 'bg-white'} shadow overflow-hidden sm:rounded-lg`}>
              <div className="px-4 py-5 sm:p-6">
                <h3 className={`text-lg leading-6 font-medium ${isDarkMode ? 'text-white' : 'text-gray-900'}`}>Submit a New Request</h3>
                <div className="mt-5">
                  {successMessage && (
                    <div className="mb-4 p-2 bg-green-100 border border-green-400 text-green-700 rounded">
                      {successMessage}
                    </div>
                  )}
                  <form onSubmit={handleSubmit}>
                    <div className="mt-1">
                      <textarea
                        id="description"
                        name="description"
                        rows="3"
                        className={`shadow-sm focus:ring-blue-500 focus:border-blue-500 mt-1 block w-full sm:text-sm border ${
                          isDarkMode 
                            ? 'border-gray-600 bg-gray-700 text-white placeholder-gray-400' 
                            : 'border-gray-300 bg-white text-gray-900 placeholder-gray-500'
                        } rounded-md`}
                        placeholder="Describe your request..."
                        value={newRequest}
                        onChange={(e) => setNewRequest(e.target.value)}
                      ></textarea>
                    </div>
                    <div className="mt-5">
                      <button
                        type="submit"
                        className={`inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white ${isDarkMode ? 'bg-blue-600 hover:bg-blue-700' : 'bg-blue-500 hover:bg-blue-600'} focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500`}
                      >
                        Submit Request
                      </button>
                    </div>
                  </form>
                </div>
              </div>
            </div>
          )}

          {activeTab === "my-requests" && (
            <div className={`${isDarkMode ? 'bg-gray-800' : 'bg-white'} shadow overflow-hidden sm:rounded-lg`}>
              <div className="px-4 py-5 sm:p-6">
                <h3 className={`text-lg leading-6 font-medium ${isDarkMode ? 'text-white' : 'text-gray-900'}`}>My Requests</h3>
                <div className="mt-5">
                  {userRequests.length === 0 ? (
                    <p className={isDarkMode ? 'text-gray-300' : 'text-gray-500'}>You have no active requests.</p>
                  ) : (
                    <ul className={`divide-y ${isDarkMode ? 'divide-gray-700' : 'divide-gray-200'}`}>
                      {userRequests.map((request) => (
                        <li key={request._id} className="py-4">
                          <div className="flex space-x-3">
                            <div className="flex-1 space-y-1">
                              <div className="flex items-center justify-between">
                                <h3 className={`text-sm font-medium ${isDarkMode ? 'text-white' : 'text-gray-900'}`}>{request.text}</h3>
                                <p className={`text-sm ${isDarkMode ? 'text-gray-400' : 'text-gray-500'}`}>{formatDate(request.createdAt)}</p>
                              </div>
                              <p className={`text-sm ${isDarkMode ? 'text-gray-400' : 'text-gray-500'}`}>Status: {request.status}</p>
                              <p className={`text-sm ${isDarkMode ? 'text-gray-400' : 'text-gray-500'}`}>Assigned Team: {request.assignedTeam}</p>
                              {request.comments && request.comments.length > 0 && (
                                <div className="mt-2">
                                  <h4 className={`text-sm font-medium ${isDarkMode ? 'text-white' : 'text-gray-900'}`}>Comments:</h4>
                                  <ul className="mt-1 space-y-1">
                                    {request.comments.map((comment, index) => (
                                      <li key={index} className={`text-sm ${isDarkMode ? 'text-gray-300' : 'text-gray-600'}`}>
                                        <p>{comment.text}</p>
                                        <p className={`text-xs ${isDarkMode ? 'text-gray-400' : 'text-gray-500'}`}>
                                          By: {comment.user.email || 'Unknown User'} on {formatDate(comment.createdAt)}
                                        </p>
                                      </li>
                                    ))}
                                  </ul>
                                </div>
                              )}
                              <div className="mt-2">
                                <textarea
                                  value={newComments[request._id] || ''}
                                  onChange={(e) => setNewComments({ ...newComments, [request._id]: e.target.value })}
                                  className={`shadow-sm focus:ring-blue-500 focus:border-blue-500 mt-1 block w-full sm:text-sm border ${isDarkMode ? 'border-gray-600 bg-gray-700 text-white' : 'border-gray-300 bg-white text-gray-900'} rounded-md`}
                                  placeholder="Add a comment..."
                                  rows="2"
                                ></textarea>
                                <button
                                  onClick={() => handleAddComment(request._id)}
                                  className={`mt-2 inline-flex items-center px-3 py-1 border border-transparent text-sm font-medium rounded-md shadow-sm text-white ${isDarkMode ? 'bg-blue-600 hover:bg-blue-700' : 'bg-blue-500 hover:bg-blue-600'} focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500`}
                                >
                                  Add Comment
                                </button>
                              </div>
                            </div>
                          </div>
                        </li>
                      ))}
                    </ul>
                  )}
                </div>
              </div>
            </div>
          )}
        </div>
      </main>

      <footer className={`${isDarkMode ? 'bg-gray-800 border-gray-700' : 'bg-white border-gray-200'} border-t`}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex items-center justify-between">
          <p className={`text-sm ${isDarkMode ? 'text-gray-400' : 'text-gray-500'}`}>&copy; 2023 IT Service Management. All rights reserved.</p>
          <nav className="flex space-x-4">
            <button onClick={() => {/* Add privacy policy logic */}} className={`text-sm ${isDarkMode ? 'text-gray-400 hover:text-white' : 'text-gray-500 hover:text-gray-900'}`}>Privacy Policy</button>
            <button onClick={() => {/* Add terms of service logic */}} className={`text-sm ${isDarkMode ? 'text-gray-400 hover:text-white' : 'text-gray-500 hover:text-gray-900'}`}>Terms of Service</button>
          </nav>
        </div>
      </footer>
    </div>
  );
};

export default Home;