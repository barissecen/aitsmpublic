import React, { useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { submitRequest, predictTeam } from '@/api/api';

const requestSchema = z.object({
  title: z.string().min(1, 'Title is required'),
  description: z.string().min(10, 'Description must be at least 10 characters'),
});

type RequestFormData = z.infer<typeof requestSchema>;

export function RequestForm() {
  const [predictedTeam, setPredictedTeam] = useState<string | null>(null);
  const { register, handleSubmit, formState: { errors }, watch } = useForm<RequestFormData>({
    resolver: zodResolver(requestSchema),
  });

  const description = watch('description');

  const onSubmit = async (data: RequestFormData) => {
    try {
      await submitRequest({ ...data, assignedTeam: predictedTeam || 'Unassigned' });
      // Handle successful submission (e.g., show success message, reset form)
    } catch (error) {
      // Handle error (e.g., show error message)
    }
  };

  const handlePredictTeam = async () => {
    if (description) {
      try {
        const result = await predictTeam(description);
        setPredictedTeam(result.predictedTeam);
      } catch (error) {
        // Handle error (e.g., show error message)
      }
    }
  };

  return (
    <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
      <div>
        <Input
          {...register('title')}
          placeholder="Request Title"
        />
        {errors.title && <p className="text-red-500">{errors.title.message}</p>}
      </div>
      <div>
        <Textarea
          {...register('description')}
          placeholder="Request Description"
          rows={4}
        />
        {errors.description && <p className="text-red-500">{errors.description.message}</p>}
      </div>
      <Button type="button" onClick={handlePredictTeam}>Predict Team</Button>
      {predictedTeam && (
        <p>Predicted Team: {predictedTeam}</p>
      )}
      <Button type="submit">Submit Request</Button>
    </form>
  );
}