import axios from 'axios';

const API_URL = 'http://localhost:5001/api';

const axiosInstance = axios.create({
  baseURL: API_URL,
  withCredentials: true,
});

// Add this function to set the token in the headers
const setAuthToken = (token) => {
  if (token) {
    axiosInstance.defaults.headers.common['Authorization'] = `Bearer ${token}`;
  } else {
    delete axiosInstance.defaults.headers.common['Authorization'];
  }
};

export const login = async (email, password) => {
  try {
    console.log('Attempting login for:', email);
    const response = await axiosInstance.post('/login', { email, password });
    console.log('Login response:', response.data);
    setAuthToken(response.data.token);
    return response.data;
  } catch (error) {
    console.error('Login error:', error.response ? error.response.data : error.message);
    throw error.response ? error.response.data : new Error('Network error');
  }
};

export const submitRequest = async (formData) => {
  try {
    const response = await axiosInstance.post('/requests', formData);
    return response.data;
  } catch (error) {
    console.error('Error submitting request:', error);
    throw error;
  }
};

export const getUserRequests = async () => {
  try {
    const response = await axiosInstance.get('/requests');
    return response.data;
  } catch (error) {
    console.error('Error fetching user requests:', error);
    throw error;
  }
};

export const signup = async (email, password) => {
  try {
    console.log('Attempting signup for:', email);
    const response = await axiosInstance.post('/signup', { email, password });
    console.log('Signup response:', response.data);
    setAuthToken(response.data.token);
    return response.data;
  } catch (error) {
    console.error('Signup error:', error);
    throw error.response ? error.response.data : new Error('Network error');
  }
};

export const addCommentToRequest = async (requestId, commentData) => {
  try {
    const response = await axiosInstance.post(`/requests/${requestId}/comments`, commentData);
    return response.data;
  } catch (error) {
    console.error('Error adding comment:', error);
    throw error;
  }
};

// Call this function when the app starts
setAuthToken(localStorage.getItem('token'));